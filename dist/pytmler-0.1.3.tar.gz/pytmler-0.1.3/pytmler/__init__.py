""""
pytmler

A smart and small package to build quick but shinny html reports in python.

"""

__version__ = "0.1.3"
__author__ = "Farhad M. Panah"
__credits__ = "University of Copenhagen, Department of Food Science"
__author_email__ = "farhad@food.ku.dk"